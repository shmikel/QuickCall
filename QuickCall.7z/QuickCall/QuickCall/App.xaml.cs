﻿using QuickCall.Models;
using QuickCall.ViewModels;
using QuickCall.Views;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace QuickCall
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void OnStartup(object sender, StartupEventArgs e)
        {
            //System.IO.File.Delete("AuthorisedUser.txt");
            MainView view = new MainView(); // создали View
            MainViewModel viewModel = new ViewModels.MainViewModel(new List<Company>()); // Создали ViewModel
            view.DataContext = viewModel; // положили ViewModel во View в качестве DataContext
            viewModel.SwitchToContactPanel += view.To_contact;
            view.Show();

        }
    }
}
