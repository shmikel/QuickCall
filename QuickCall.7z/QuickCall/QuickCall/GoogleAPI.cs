﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Util.Store;
using Google.Apis.Services;
using QuickCall.Views;
using System.Net;
using Google.GData.Client;
using Google.Contacts;
using Google.GData.Extensions;
using Google.GData.Contacts;
using System.Windows;
using System.Net.NetworkInformation;

namespace QuickCall
{
    public class GoogleAPI
    {

        string yourAppClientID = "249162294080-5tfguaqhgqa8hb6f2qdgs5rm5td9vlpm.apps.googleusercontent.com";
        string yourAppClientSecret = "UlFk7Wy94O8G9ts92dcZ-c-m";
        string userEmail;
        ContactsRequest cr;

        public GoogleAPI()
        {
            ForgetMe();
        }

        private bool AmIOnline()
        {
            if (!CheckConnection()) { throw new AccessViolationException("No Internet Connection. Try later."); }
            if (userEmail == null)
            {
                var window = new EmailInput();
                window.SentEmail += c => { userEmail = c; };
                window.ShowDialog();

            }
            if (userEmail == null) { return false; }

            // Параметры Авторизации
            //string gmailScope = "https://mail.google.com/";
            string contactScope = "https://www.google.com/m8/feeds";
            string[] scopes = new string[1];
            //scopes[0] = gmailScope;
            scopes[0] = contactScope;

            //Авторизация 
            UserCredential credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
            new ClientSecrets
            {
                ClientId = yourAppClientID,
                ClientSecret = yourAppClientSecret,
            },
             scopes,
             "user",
             CancellationToken.None).Result;
            Task.WaitAll();

            // РеАвторизация
            if (credential.Token.IsExpired(credential.Flow.Clock))
                if (!credential.RefreshTokenAsync(CancellationToken.None).Result)
                {
                    throw new ClientQueryException ("We can't refresh your token!");
                }
            Task.WaitAll();

            var StreamWriter = System.IO.File.CreateText("AuthorisedUser.txt");
            StreamWriter.Write(userEmail);
            StreamWriter.Close();

            //Создаем параметры для запроса
            var settings = new RequestSettings("QuickCall");
            settings.OAuth2Parameters = new OAuth2Parameters() { AccessToken = credential.Token.AccessToken, ClientId = yourAppClientID, ClientSecret = yourAppClientSecret };

            // Создаем сам запрос, механизм запросов.
            cr = new ContactsRequest(settings);

            return true;
        }
        public void PreChangeUser() 
        {
            userEmail = null;
            ForgetMe();
        }
        private void ForgetMe()
        {
            bool clearSavedToken = true;
            if (clearSavedToken)
            {
                FileDataStore ds = new FileDataStore(GoogleWebAuthorizationBroker.Folder);
                ds.DeleteAsync<TokenResponse>("user").Wait();
            }
        }

        public bool CheckConnection()
        {
            IPStatus status = IPStatus.Unknown;
            try
            {
                Ping p = new Ping();
                PingReply pr = p.Send(@"server.ru");
                status = pr.Status;
            }
            catch { }
            if (status == IPStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Group CheckQuickCallGroup()
        {
            if (!AmIOnline()) { throw new Exception("Нет Интернет соединения либо вам отказано в доступе."); };
            Feed<Group> fg = cr.GetGroups();
            foreach (Group group in fg.Entries)
            {
                if (group.Title.Trim() == "QuickCall") { return group; }
                //Console.WriteLine("Self Link: " + group.Self);
            }

            Group newGroup = new Group();
            newGroup.Title = "QuickCall";

            Group createdGroup = cr.Insert(new Uri("https://www.google.com/m8/feeds/groups/default/full"),
                newGroup);

            return createdGroup;

        }

        public void AddContact(Contact c)
        {
            var QuickCall_group = CheckQuickCallGroup();
            var groupLink = QuickCall_group.Self.Replace("full", "base");
            c.GroupMembership.Add(new GroupMembership
            {
                HRef = groupLink
            });
            Uri feedUri = new Uri(ContactsQuery.CreateContactsUri("default"));
            Contact createdEntry = cr.Insert(feedUri, c);
            
        }
    }
}
