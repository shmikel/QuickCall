﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QuickCall.Models
{
    public class Question
    {
        public string Text { get; set; }
        public string City { get; set; }
        public string CountRes { get; set; }
        public Question(string text = "", string city = "")
        {
            Text = text;
            City = city;
            CountRes = "";
        }
    }
}
