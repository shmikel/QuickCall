﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QuickCall.Models;

namespace QuickCall.ViewModels
{
    public class CompanyViewModel : ViewModelBase
    {
        private Company _сompany;
        public Company Company { get { return _сompany; } }
        public CompanyViewModel(Company Company)
        {
            this._сompany = Company;
        }

        public string Name
        {
            get { return _сompany.Name; }
            set
            {
                _сompany.Name = value;
                OnPropertyChanged("Name");
            }
        }
        public string Address
        {
            get { return _сompany.Address; }
            set
            {
                _сompany.Address = value;
                OnPropertyChanged("Address");
            }
        }
        public string Url
        {
            get { return _сompany.Url; }
            set
            {
                _сompany.Url = value;
                OnPropertyChanged("Url");
            }
        }
        public DTO.Phone[] Phones
        {
            get { return _сompany.Phones; }
            set
            {
                _сompany.Phones = value;
                OnPropertyChanged("Name");
            }
        }
        public DTO.Link[] Links
        {
            get { return _сompany.Links; }
            set
            {
                _сompany.Links = value;
                OnPropertyChanged("Links");
            }
        }
        public string Links_inline
        {
            get { return _сompany.Links_inline; }
            set
            {
                _сompany.Links_inline = value;
                OnPropertyChanged("Links_inline");
            }
        }
        public string Phones_inline
        {
            get { return _сompany.Phones_inline; }
            set
            {
                _сompany.Phones_inline = value;
                OnPropertyChanged("Phones_inline");
            }
        }

    }
}
