﻿using QuickCall.Commands;
using QuickCall.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace QuickCall.ViewModels
{
    public class QuestionViewModel : ViewModelBase
    {
        public Question Question;
        public Action<List<Company>> sentCompanies;

        public QuestionViewModel(Question Question)
        {
            this.Question = Question;
        }

        public string Text
        {
            get { return Question.Text; }
            set
            {
                Question.Text = value;
                OnPropertyChanged("Text");
            }
        }
        public string City
        {
            get { return Question.City; }
            set
            {
                Question.City = value;
                OnPropertyChanged("City");
            }
        }
        public string CountRes
        {
            get { return Question.CountRes; }
            set
            {
                Question.CountRes = value;
                OnPropertyChanged("Count");
            }
        }

        #region Commands

        #region Поиск

        private DelegateCommand searchCommand;

        public ICommand SearchCommand
        {
            get
            {
                if (searchCommand == null)
                {
                    searchCommand = new DelegateCommand(Search);
                }
                return searchCommand;
            }
        }

        private void Search()
        {
            SwitchBar("On");
            Text = Text.Trim();
            City = City.Trim();
            if (Text == "") { MessageBox.Show("Вы забыли ввести запрос!"); SwitchBar(""); return; }
            if (City == "") { MessageBox.Show("Вы не указали город!"); SwitchBar(""); return; }

            YandexAPI API = null;
            DTO.MainData queryResult = null;
            Task t1 = Task.Factory.StartNew(() =>
            {
                try
                {
                    API = new YandexAPI();
                }
                catch { MessageBox.Show("No Internet connection or Wrong settings!\n Try again!"); SwitchBar(""); return; }
                try
                {

                    try { queryResult = API.Query(Text + " г. " + City, int.Parse(CountRes.Trim())); }
                    catch (Exception ex) { queryResult = API.Query(Text + " г. " + City); }

                    var CompanyList = new List<Company>(queryResult.Features.Select(a => new Company(a)));

                    sentCompanies(CompanyList);
                    SwitchBar("");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    SwitchBar("");
                    return;
                }
            });

        }

        #region SwitchBar
        public Visibility _barVis = Visibility.Hidden;
        public Visibility _butVis = Visibility.Visible;
        public bool _progress = false;
        public Visibility BarVisibility
        {
            get { return _barVis; }
            set
            {
                _barVis = value;
                OnPropertyChanged("BarVisibility");
            }
        }
        public Visibility ButtonVisibility
        {
            get { return _butVis; }
            set
            {
                _butVis = value;
                OnPropertyChanged("ButtonVisibility");
            }
        }
        public bool BarProgress
        {
            get { return _progress; }
            set
            {
                _progress = value;
                OnPropertyChanged("BarProgress");
            }
        }
        private void SwitchBar(string sw)
        {
            if (sw == "On")
            {
                ButtonVisibility = Visibility.Hidden;
                BarProgress = true;
                BarVisibility = Visibility.Visible;
            }
            else
            {
                ButtonVisibility = Visibility.Visible;
                BarProgress = false;
                BarVisibility = Visibility.Hidden;
            }
        }
        #endregion

        #endregion

        #endregion

    }
}
