﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;

using QuickCall.Commands;
using QuickCall.ViewModels;
using System.Collections.ObjectModel;
using QuickCall.Models;
using Google.Contacts;
using Google.GData.Extensions;
using System.Threading.Tasks;

namespace QuickCall.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        public ObservableCollection<CompanyViewModel> CompanyList { get; set; }
        public QuestionViewModel QuestPanel { get; set; }
        public ContactViewModel ContactPanel { get; set; }
        private GoogleAPI G_api;


        #region Constructor

        public MainViewModel(List<Company> companies)
        {
            G_api = new GoogleAPI();
            CompanyList = new ObservableCollection<CompanyViewModel>(companies.Select(b => new CompanyViewModel(b)));

            GenContactPanel();
            //
            QuestPanel = new QuestionViewModel(new Question());
            QuestPanel.sentCompanies += (A) =>
            {
                CompanyList = new ObservableCollection<CompanyViewModel>(A.Select(b => new CompanyViewModel(b)));
                OnPropertyChanged("CompanyList");
                if (A.Count == 0)
                {
                    Hint = "К сожалению, по запросу:\n \""+QuestPanel.Text+" г."+QuestPanel.City+"\"\n ничего не найдено!";
                    HintVis = Visibility.Visible;
                    OnPropertyChanged("Hint");
                }
                else
                {
                    HintVis = Visibility.Hidden;
                    OnPropertyChanged("HintVis");
                }
            };

        }

        public void GenContactPanel()
        {
            var c = new Contact();
            c.Name.FullName = "";
            c.Name.GivenName = "";
            c.Name.FamilyName = "";
            c.Emails.Add(new EMail() { Address = "" });
            c.PostalAddresses.Add(new StructuredPostalAddress() { FormattedAddress = "" });
            c.Content = "Created by QuickCall";
            ContactPanel = new ContactViewModel(c, G_api);
            ContactPanel.ClearAll += GenContactPanel;
            OnPropertyChanged("ContactPanel");
        }
        public void GenContactPanel(Contact c)
        {
            ContactPanel = new ContactViewModel(c, G_api);
            ContactPanel.ClearAll += GenContactPanel;
            OnPropertyChanged("ContactPanel");
        }


        #endregion

        #region Справка о программе
        private string _hint = " \nQuickCall - это:\n\n -Универсальный поиск организаций и учреждений.\n -Мгновенное добавление номеров в телефонную книгу android.\n\n\n\n\nДля полноценной работы приложения необходимо:\n-Включить интернет на телефоне (связанном с вашим аккаунтом Google) и компьютере\n-Включить на телефоне автосинхронизацию контактов\n-Возможно понадобится включить в приложении для совершения звонков видимость группы QuickCall";

        public string Hint
        {
            get { return _hint; }
            set
            {
                _hint = value;
                base.OnPropertyChanged("Hint");
            }
        }

        private Visibility _hintVis = Visibility.Visible;
        public Visibility HintVis
        {
            get { return _hintVis; }
            set
            {
                _hintVis = value;
                base.OnPropertyChanged("HintVis");
            }
        }
        #endregion

        #region SelectedItem

        private Visibility _alowButton = Visibility.Hidden;
        public Visibility AlowButton
        {
            get { return _alowButton; }
            set
            {
                _alowButton = value;
                base.OnPropertyChanged("AlowButton");
            }
        }
        private CompanyViewModel p_SelectedItem;
        public CompanyViewModel SelectedItem
        {
            get { return p_SelectedItem; }

            set
            {
                p_SelectedItem = value;
                if (value != null) { AlowButton = Visibility.Visible; } else { AlowButton = Visibility.Hidden; }
                base.OnPropertyChanged("SelectedItem");
            }
        }
        #endregion

        #region Сохранение контакта
        public Action SwitchToContactPanel;
        private DelegateCommand saveCommand;
        public ICommand SaveC
        {
            get
            {
                if (saveCommand == null)
                {
                    saveCommand = new DelegateCommand(SaveContact);
                }
                return saveCommand;
            }
        }

        private void SaveContact()
        {
            if (SelectedItem == null) { MessageBox.Show("Компания не выбрана!"); return; }
            // вызов перехода к вкладке контакт
            if (SwitchToContactPanel != null) { SwitchToContactPanel(); }

            var c = new Contact();
            try // телефонов может не быть
            {
                foreach (var item in SelectedItem.Phones)
                {
                    c.Phonenumbers.Add(new PhoneNumber()
                        {
                            Rel = ContactsRelationships.IsOther,
                            Value = item.Formatted,
                        });
                }
            }
            catch { }

            c.Name.FullName = SelectedItem.Name;
            c.Name.GivenName = SelectedItem.Name;
            c.Name.FamilyName = "";
            c.Emails.Add(new EMail() { Address = "" });
            c.PostalAddresses.Add(new StructuredPostalAddress() { FormattedAddress = SelectedItem.Address });
            c.Content = "Created by QuickCall";
            GenContactPanel(c);
        }

        #endregion

        #region Закрыть программу
        private DelegateCommand exitCommand;
        public ICommand ExitCommand
        {
            get
            {
                if (exitCommand == null)
                {
                    exitCommand = new DelegateCommand(Exit);
                }
                return exitCommand;
            }
        }

        private void Exit()
        {
            Application.Current.Shutdown();
        }
        #endregion
    }
}
