﻿using Google.Contacts;
using Google.GData.Extensions;
using QuickCall.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows;
using System.Windows.Input;

namespace QuickCall.ViewModels
{
    public class ContactViewModel : ViewModelBase
    {
        private Contact Contact;
        public Action ClearAll;
        public GoogleAPI API;

        public ContactViewModel(Contact Contact, GoogleAPI api)
        {
            while (Contact.Phonenumbers.Count < 20) { Contact.Phonenumbers.Add(new PhoneNumber()); }
            Contact.PostalAddresses.Add(new StructuredPostalAddress());//Если уже есть, то не высветится, а так лишним не будет
            Contact.Emails.Add(new EMail());// аналогично
            this.Contact = Contact;
            API = api;
        }

        public string FullName
        {
            get { return Contact.Name.FullName; }
            set
            {
                Contact.Name.FullName = value;
                OnPropertyChanged("FullName");
            }
        }
        public string GivenName
        {
            get { return Contact.Name.GivenName; }
            set
            {
                Contact.Name.GivenName = value;
                OnPropertyChanged("GivenName");
            }
        }
        public string FamilyName
        {
            get { return Contact.Name.FamilyName; }
            set
            {
                Contact.Name.FamilyName = value;
                OnPropertyChanged("FamilyName");
            }
        }
        public string Content
        {
            get { return Contact.Content; }
            set
            {
                Contact.Content = value;
                OnPropertyChanged("Content");
            }
        }
        public ExtensionCollection<PhoneNumber> Phonelist
        {
            get { return Contact.Phonenumbers; }
            set
            {
                foreach (var item in value)
                {
                    Contact.Phonenumbers.Add(item);
                }
                OnPropertyChanged("Phonelist");

            }
        }
        public string Address
        {
            get { return Contact.PostalAddresses[0].FormattedAddress; }
            set
            {
                Contact.PostalAddresses[0].FormattedAddress = value;
                OnPropertyChanged("Address");
            }
        }
        public string Email
        {
            get { return Contact.Emails[0].Address; }
            set
            {
                Contact.Emails[0].Address = value;
                OnPropertyChanged("Email");
            }
        }

        #region Commands

        #region Загрузка контакта

        private DelegateCommand okcommand;

        public ICommand OKCommand
        {
            get
            {
                if (okcommand == null)
                {
                    okcommand = new DelegateCommand(UploadContact);
                }
                return okcommand;
            }
        }

        private void UploadContact()
        {

            if (((Email.Trim().IndexOf('@') == -1) || (Email.Trim().IndexOf('.') == -1)) && (Email.Trim().Count() != 0))
            {
                MessageBox.Show("E-mail address is wrong!");
                return;
            }

            #region Сборка контакта
            var c = new Contact();
            try
            {
                c.Name = Contact.Name;
                c.Content = Contact.Content;
                if (Email != null)
                    if (Email.Trim() != "")
                    {
                        c.Emails.Add(new EMail()
                        {
                            Primary = true,
                            Rel = ContactsRelationships.IsOther,
                            Address = Email,
                        });
                    }

                c.PostalAddresses.Add(new StructuredPostalAddress()
                {
                    Rel = ContactsRelationships.IsOther,
                    Primary = true,
                    Street = "",
                    City = "",
                    Region = "",
                    Postcode = "",
                    Country = "",
                    FormattedAddress = Address,
                });
                foreach (var item in Contact.Phonenumbers)
                {
                    if (item.Value != null)
                    {
                        if (item.Value.Trim() != "")
                        {
                            if (item.Rel == null) { item.Rel = ContactsRelationships.IsOther; }
                            c.Phonenumbers.Add(item);
                        }
                    }
                }

            }
            catch { MessageBox.Show("Часть полей заполненно неверно!"); return; }
            #endregion
            try
            {
                API.AddContact(c);
                MessageBox.Show("Контакт успешно добавлен!");
                if (ClearAll != null) { ClearAll(); }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }


        }

        #region ClearAll
        private DelegateCommand clearcommand;

        public ICommand ClearAllCommand
        {
            get
            {
                if (clearcommand == null)
                {
                    clearcommand = new DelegateCommand(delegate()
                    {
                        if (ClearAll != null)
                        {
                            ClearAll();
                        }
                    });
                }
                return clearcommand;
            }
        }

        #endregion
        #region SignOut
        private DelegateCommand signoutcommand;

        public ICommand SignOutCommand
        {
            get
            {
                if (signoutcommand == null)
                {
                    signoutcommand = new DelegateCommand(SignOut);
                }
                return signoutcommand;
            }
        }

        private void SignOut()
        {
            API.PreChangeUser();
            MessageBox.Show("Выход осуществлён!");
        }
        #endregion


        #endregion

        #endregion

    }

}
