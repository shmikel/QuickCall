﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace QuickCall.Views
{
    /// <summary>
    /// Interaction logic for EmailInput.xaml
    /// </summary>
    public partial class EmailInput : Window
    {
        public Action<string> SentEmail;
        public EmailInput()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if ((eBox.Text.IndexOf('@') == -1)||(eBox.Text.IndexOf('.') == -1)) 
            {
                MessageBox.Show("Your e-mail is wrong!");
                return;
            }
            SentEmail(eBox.Text.Trim());
            Close();
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
