﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using QuickCall.ViewModels;

namespace QuickCall.Views
{
    /// <summary>
    /// Interaction logic for MainView.xaml
    /// </summary>
    public partial class MainView : Window
    {
        public MainView()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void Button_Switch_Mode(object sender, RoutedEventArgs e)
        {
            #region Смена карточек

            var color = ColorTranslator.FromHtml("#0796A2");
            var myBrush = new SolidColorBrush(System.Windows.Media.Color.FromArgb(color.A, color.R, color.G, color.B));

            if (((Button)sender).Name == "Button_Contact")
            {
                Button_Contact.Background = System.Windows.Media.Brushes.White;
                Button_Company.Background = myBrush;
                Company_Card.Visibility = Visibility.Hidden;
                Contact_Card.Visibility = Visibility.Visible;
                SaveC.Visibility = Visibility.Hidden;
            }
            else
            {
                Button_Contact.Background = myBrush;
                Button_Company.Background = System.Windows.Media.Brushes.White;
                Company_Card.Visibility = Visibility.Visible;
                Contact_Card.Visibility = Visibility.Hidden;
                SaveC.Visibility = Visibility.Visible;
            }
            #endregion
        }

        public void To_contact()
        {
            #region Смена карточек

            var color = ColorTranslator.FromHtml("#0796A2");
            var myBrush = new SolidColorBrush(System.Windows.Media.Color.FromArgb(color.A, color.R, color.G, color.B));


            Button_Contact.Background = System.Windows.Media.Brushes.White;
            Button_Company.Background = myBrush;
            Company_Card.Visibility = Visibility.Hidden;
            Contact_Card.Visibility = Visibility.Visible;
            SaveC.Visibility = Visibility.Hidden;

            #endregion
        }

        private void OnlyDigits(object sender, KeyEventArgs e)
        {
            string[] alow = new string[] { "D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "OemPlus" };
            foreach (var item in alow)
            {
                if (item == e.Key.ToString()) { return; }
            }
            //MessageBox.Show("Очень жаль, но в бесплатной версии вы не сможете изменять номера телефонов!");
            e.Handled = true;
        }

    }
}
